﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace WeakSven
{
    class Bullet:BulletEntity
    {
            public Texture2D texture;
            public Vector2 position;     
            public bool isvisible;
            public List<Bullet> LiveBullets;
            SpriteBatch spriteBatch;
            GraphicsDeviceManager graphics;
            public Player player;
            public Bullet(Vector2 position, Vector2 velocity)
            {
                image = Level.Bullet;
                Position = position;
                Velocity = velocity;
                Orientation = Velocity.ToAngle();
                Radius = 8;
            }


            public void Update()
            {
                if (Velocity.LengthSquared() > 0)
                    Orientation = Velocity.ToAngle();
                //ToAngle needs to be created


                Position += Velocity;

                // delete bullets that go off-screen

                IsExpired = true;
                //Viewport is screen. Needs to be applied as such. =D
                //ToPoint will be where the bullets go. Must work on this. (Check Game1)
            }

            public void Load(ContentManager Content) {

              //  spriteBatch = new SpriteBatch(GraphicsDevice);

               
                LiveBullets = new List<Bullet>();
                texture = Content.Load<Texture2D>("Bullet");
            }


    }
}

