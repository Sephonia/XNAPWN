﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using System;

namespace WeakSven
{
    // sealed
    class Player : InteractiveCharacter
    {
        const int cooldownFrames = 6;

        int cooldownRemaining = 0;
        static Random rand = new Random();
        int framesUntilRespawn = 0;
        public bool IsDead
        {
            get { return framesUntilRespawn > 0; }
        }
        #region Singleton Stuff
        private static Player instance = null;
        public static Player Instance
        {
            get
            {
                if (instance == null)
                    instance = new Player();

                return instance;
            }
        }


        private Player() : base() { Speed = 2.00f; }
        #endregion

        //public AudioSFX bing = new AudioSFX();

        public void SetName(string name) { Name = name; }

        protected int health = 100;
        public int Health
        {
            get { return health; }
            set
            {
                health = value;
                if (health < 0)
                    health = 0;
            }
        }

        public KeyboardState lastKey;
        private bool movingX = false;
        private bool movingY = false;

        public override void Load(ContentManager Content, string imageFile)
        {
            base.Load(Content, imageFile);

        }

        public void Kill()
        {
            framesUntilRespawn = 60;
            //need a playerStatus then remove life. =D
            //PlayerStatus.RemoveLife();
            //framesUntilRespawn = PlayerStatus.IsGameOver ? 300 : 120;
        }

        public override void Update(GameTime gameTime)
        {
            if (IsDead)
            {
                framesUntilRespawn--;
                return;
            }
            /*var aim = lastKey;
            if (cooldownRemaining <= 0)
            {
                cooldownRemaining = cooldownFrames;
                
                Quaternion aimQuat = Quaternion.CreateFromYawPitchRoll(0, 0, aim);

                float randomSpread = rand.NextFloat(-0.04f, 0.04f) + rand.NextFloat(-0.04f, 0.04f);
                Vector2 vel = FromPolar(aim + randomSpread, 11f);

                Vector2 offset = Vector2.Transform(new Vector2(25, -8), aimQuat);
                EntityManager.Add(new Bullet(Position + offset, vel));

                offset = Vector2.Transform(new Vector2(25, 8), aimQuat);
                EntityManager.Add(new Bullet(Position + offset, vel));
            }

            if (cooldownRemaining > 0)
                cooldownRemaining--;
            movingX = movingY = false;*/

            // TODO:  Change player controls to fit your game


            if (Keyboard.GetState().IsKeyDown(Keys.W) ||
                Keyboard.GetState().IsKeyDown(Keys.Up))
            {
                Velocity.Y = -Speed;
                movingY = true;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.A) ||
                Keyboard.GetState().IsKeyDown(Keys.Left))
            {
                Velocity.X = -Speed;
                movingX = true;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.S) ||
                Keyboard.GetState().IsKeyDown(Keys.Down))
            {
                Velocity.Y = Speed;
                movingY = true;
            }

            if (Keyboard.GetState().IsKeyDown(Keys.D) ||
                Keyboard.GetState().IsKeyDown(Keys.Right))
            {
                Velocity.X = Speed;
                movingX = true;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Space)) { 
                
            }
            if (!movingX)
                Velocity.X = 0;

            if (!movingY)
                Velocity.Y = 0;

            lastKey = Keyboard.GetState();
            base.Update(gameTime);
         

            //----------------------------------------------
        }
        
            // If there's no aim input, return zero. Otherwise normalize the direction to have a length of 1.

        


        public static Vector2 FromPolar(float angle, float magnitude)
        {
            return magnitude * new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle));
        }


    }
}

//Quaternion info http://twistedoakgames.com/blog/?p=144
// in Extensions

