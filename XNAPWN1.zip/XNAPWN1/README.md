FHSQR
======
